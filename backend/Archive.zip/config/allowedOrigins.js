const allowedOrigins = ["http://localhost:8081"];

module.exports = allowedOrigins;
