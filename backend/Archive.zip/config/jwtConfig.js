const jwtConfig = {
    expiration: '7d',
    secretKey: "kujkas%!@#$234/**ds-387*-/-+a"
}

module.exports = jwtConfig;